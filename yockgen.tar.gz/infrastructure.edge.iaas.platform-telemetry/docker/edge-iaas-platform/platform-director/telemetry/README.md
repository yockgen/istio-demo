## Telemetry Docker-Compose

### Overall Telemetry architecture and Docker Deployment 
[/helm/edge-iaas-platform/telemetry/README.md](/helm/edge-iaas-platform/platform-director/telemetry/README.md)
